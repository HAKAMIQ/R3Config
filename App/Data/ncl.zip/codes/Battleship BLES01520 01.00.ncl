Memory 15 Handgun Ammo
0
jgduff1
0 3087BD7C 0000000F
#
Memory 300 Aliens Gun Ammo
0
jgduff1
0 308A1698 0000012C
#
Memory Infinite Health
0
jgduff1
0 33DE011C 42C80000
0 33DE0394 42C80000
/*
You can kill CPU with 2
or 3 head shots or
grenades.

It might mess up game
progression.
*/
#
ASM Infinite Health
0
jgduff1
0 00052810 C1BF0000 
0 00052828 EDBE682A
#
Memory Guns Never Overheat
0
jgduff1
0 30152A94 00000000
0 307C074C 00000000
#